const app = require("./server");

app.listen(3000, () =>
  console.log("Airport API ready. Documents at http://localhost:3000/api-docs")
);
