1. npm install
2. nodemon start.js (having nodemon installed globally useful)

API docs then available at [url](http://localhost:3000/api-docs)
